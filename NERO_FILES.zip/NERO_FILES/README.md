                  _/      _/     _/_/_/_/     _/_/_/         _/_/
                 _/_/    _/     _/           _/    _/     _/    _/
        Dev by: _/  _/  _/     _/_/_/       _/_/_/       _/    _/
               _/    _/_/     _/           _/    _/     _/    _/
              _/      _/     _/_/_/_/     _/    _/       _/_/


## !Please READ before!

At the moment this page can convert videos and photos to other formats 

## INSTALATION
Installation:npm install
             Run: "npm run dev" or "npm start de"
             install pandoc: choco install pandoc (require admin acces)
             check installtion pandoc: pandoc --version
Contribution:
            add files: git add . 
            commit: git commit -m "Mensaje descriptivo del commit"
            connect: git add -u origin https://github.com/FrancoJOG/Nero
            push: git push -u origin master
            clone: git clone https://github.com/FrancoJOG/Nero
            check URL: git remote -v
            Change URL: git remote set-url origin new_url
Folders: html = views
         public: temporal data
         routes: routing file
         
Aditional Documentation:

Licenses: n/a

Last update: 27/08/2023-20/08/2023
Version:0.2.0
Status: This project is in development
About us: we are hungri
discord: N/A
Support: Marvin sabe, yo no
Credits: help the boss doesn't pay us
         Franco Joseph Ortega Gutierrez
         Shineon

This project was created by Nero.
Test $ cloudflared tunnel --url http://localhost:4000